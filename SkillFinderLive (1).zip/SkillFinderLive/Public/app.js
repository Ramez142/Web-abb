const state = {
  token: null,
  role: null,
  displayName: null,
  username: null
};

const loginSection = document.getElementById('login-section');
const studentDashboard = document.getElementById('student-dashboard');
const professorDashboard = document.getElementById('prof-dashboard');
const loginForm = document.getElementById('login-form');
const loginError = document.getElementById('login-error');
const toast = document.getElementById('toast');

const studentName = document.getElementById('student-name');
const studentCoursesList = document.getElementById('student-courses');
const studentHistoryList = document.getElementById('student-history');
const manualSessionInput = document.getElementById('manual-session-code');
const manualSubmitBtn = document.getElementById('manual-submit-btn');
const startScanBtn = document.getElementById('start-scan-btn');
const stopScanBtn = document.getElementById('stop-scan-btn');

const profName = document.getElementById('prof-name');
const profCourseSelect = document.getElementById('prof-course-select');
const createSessionBtn = document.getElementById('create-session-btn');
const sessionDateInput = document.getElementById('session-date');
const sessionResultBox = document.getElementById('session-result');
const sessionCodeText = document.getElementById('session-code-text');
const sessionBarcodeSvg = document.getElementById('session-barcode');
const sessionsList = document.getElementById('sessions-list');
const attendanceDetailsBox = document.getElementById('attendance-details');
const attendanceStudentsList = document.getElementById('attendance-students');

let qrScanner = null;

loginForm.addEventListener('submit', async (e) => {
  e.preventDefault();
  loginError.classList.add('hidden');
  loginError.textContent = '';

  const username = document.getElementById('login-username').value.trim();
  const password = document.getElementById('login-password').value;

  if (!username || !password) {
    showError('دخل البيانات كاملة لو سمحت');
    return;
  }

  try {
    const res = await fetch('/api/auth/login', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ username, password })
    });

    const data = await res.json();

    if (!res.ok) {
      showError(data.error || 'حصل خطأ في الدخول');
      return;
    }

    state.token = data.token;
    state.role = data.role;
    state.displayName = data.displayName;
    state.username = data.username;

    document.getElementById('login-password').value = '';

    if (state.role === 'student') {
      showStudentDashboard();
    } else if (state.role === 'professor') {
      showProfessorDashboard();
    } else {
      showError('النوع ده من المستخدمين مش مدعوم');
    }
  } catch (err) {
    showError('حصلت مشكلة في السيرفر، جرب بعد شوية');
    console.error(err);
  }
});

document.querySelectorAll('.logout-btn').forEach((btn) => {
  btn.addEventListener('click', logout);
});

manualSubmitBtn.addEventListener('click', async () => {
  const code = manualSessionInput.value.trim();
  if (!code) {
    showToast('اكتب الكود الأول');
    return;
  }
  await sendAttendance(code);
});

startScanBtn.addEventListener('click', startScanner);
stopScanBtn.addEventListener('click', stopScanner);

profCourseSelect.addEventListener('change', async () => {
  sessionResultBox.classList.add('hidden');
  attendanceDetailsBox.classList.add('hidden');
  sessionBarcodeSvg.innerHTML = '';
  await loadProfessorSessions();
});

createSessionBtn.addEventListener('click', async () => {
  const courseId = Number(profCourseSelect.value);
  const sessionDate = sessionDateInput.value;

  if (!courseId) {
    showToast('اختار الكورس الأول يا دكتور');
    return;
  }
  if (!sessionDate) {
    showToast('حدد التاريخ من فضلك');
    return;
  }

  try {
    const res = await authFetch('/api/prof/sessions', {
      method: 'POST',
      body: JSON.stringify({ courseId, sessionDate })
    });
    const data = await res.json();

    if (!res.ok) {
      showToast(data.error || 'حصلت مشكلة في إنشاء الجلسة');
      return;
    }

    sessionResultBox.classList.remove('hidden');
    sessionCodeText.textContent = data.sessionCode;
    JsBarcode(sessionBarcodeSvg, data.sessionCode, {
      format: 'CODE128',
      width: 2,
      height: 80,
      displayValue: true
    });

    showToast('اتعملت الجلسة والباركود جاهز 🎉');
    await loadProfessorSessions();
  } catch (err) {
    console.error(err);
    showToast('في مشكلة في الاتصال بالسيرفر');
  }
});

async function showStudentDashboard() {
  loginSection.classList.add('hidden');
  professorDashboard.classList.add('hidden');
  studentDashboard.classList.remove('hidden');

  studentName.textContent = state.displayName || state.username;

  await Promise.all([loadStudentCourses(), loadStudentHistory()]);
}

async function showProfessorDashboard() {
  loginSection.classList.add('hidden');
  studentDashboard.classList.add('hidden');
  professorDashboard.classList.remove('hidden');

  profName.textContent = state.displayName || state.username;

  await loadProfessorCourses();
}

function logout() {
  stopScanner();
  state.token = null;
  state.role = null;
  state.displayName = null;
  state.username = null;

  loginSection.classList.remove('hidden');
  studentDashboard.classList.add('hidden');
  professorDashboard.classList.add('hidden');
  attendanceDetailsBox.classList.add('hidden');
  sessionResultBox.classList.add('hidden');

  loginForm.reset();
  manualSessionInput.value = '';
  profCourseSelect.innerHTML = '<option value="">— اختار —</option>';
  studentCoursesList.innerHTML = '';
  studentHistoryList.innerHTML = '';
  sessionsList.innerHTML = '';
  attendanceStudentsList.innerHTML = '';
}

async function loadStudentCourses() {
  try {
    const res = await authFetch('/api/student/courses');
    if (!res.ok) {
      throw new Error('مش قادر أجيب المواد');
    }
    const courses = await res.json();
    if (!Array.isArray(courses) || courses.length === 0) {
      studentCoursesList.innerHTML = '<li>لسه مش مسجّل في مواد.</li>';
      return;
    }
    studentCoursesList.innerHTML = courses
      .map(
        (course) =>
          `<li><strong>${course.name}</strong> — كود: <code>${course.code}</code></li>`
      )
      .join('');
  } catch (err) {
    console.error(err);
    studentCoursesList.innerHTML = '<li>في مشكلة في تحميل المواد.</li>';
  }
}

async function loadStudentHistory() {
  try {
    const res = await authFetch('/api/student/history');
    if (!res.ok) {
      throw new Error('مش قادر أجيب التاريخ');
    }
    const history = await res.json();
    if (!Array.isArray(history) || history.length === 0) {
      studentHistoryList.innerHTML = '<li>لسه مفيش حضور مسجل.</li>';
      return;
    }
    studentHistoryList.innerHTML = history
      .map((item) => {
        const date = item.sessionDate;
        const time = new Date(item.scannedAt).toLocaleTimeString('ar-EG', {
          hour: '2-digit',
          minute: '2-digit'
        });
        return `<li>
          <div><strong>${item.courseName}</strong></div>
          <div>التاريخ: ${date}</div>
          <div>الوقت: ${time}</div>
        </li>`;
      })
      .join('');
  } catch (err) {
    console.error(err);
    studentHistoryList.innerHTML = '<li>حصلت مشكلة في عرض التاريخ.</li>';
  }
}

async function loadProfessorCourses() {
  try {
    const res = await authFetch('/api/prof/courses');
    if (!res.ok) {
      throw new Error('مش قادر أجيب الكورسات');
    }
    const courses = await res.json();
    if (!Array.isArray(courses) || courses.length === 0) {
      profCourseSelect.innerHTML = '<option value="">مفيش كورسات مرتبطة بيك</option>';
      return;
    }
    profCourseSelect.innerHTML =
      '<option value="">— اختار —</option>' +
      courses
        .map(
          (course) =>
            `<option value="${course.id}">${course.name} (${course.code})</option>`
        )
        .join('');
  } catch (err) {
    console.error(err);
    showToast('حصلت مشكلة في تحميل الكورسات');
  }
}

async function loadProfessorSessions() {
  const courseId = Number(profCourseSelect.value);
  if (!courseId) {
    sessionsList.innerHTML = '<li>اختار كورس علشان تشوف الجلسات.</li>';
    return;
  }
  try {
    const res = await authFetch(`/api/prof/sessions/${courseId}`);
    if (!res.ok) {
      throw new Error('مش قادر أجيب الجلسات');
    }
    const sessions = await res.json();
    if (!Array.isArray(sessions) || sessions.length === 0) {
      sessionsList.innerHTML = '<li>لسه مفيش جلسات للكورس ده.</li>';
      return;
    }
    sessionsList.innerHTML = sessions
      .map((session) => {
        return `<li>
          <div><strong>التاريخ:</strong> ${session.sessionDate}</div>
          <div><strong>الكود:</strong> <code>${session.sessionCode}</code></div>
          <div><strong>عدد الحضور:</strong> ${session.attendanceCount}</div>
          <button class="secondary" data-session-id="${session.id}">عرض التفاصيل</button>
        </li>`;
      })
      .join('');

    sessionsList.querySelectorAll('button').forEach((btn) => {
      btn.addEventListener('click', () => {
        const sessionId = btn.getAttribute('data-session-id');
        loadAttendanceDetails(sessionId);
      });
    });
  } catch (err) {
    console.error(err);
    sessionsList.innerHTML = '<li>حصلت مشكلة في تحميل الجلسات.</li>';
  }
}

async function loadAttendanceDetails(sessionId) {
  try {
    const res = await authFetch(`/api/prof/sessions/${sessionId}/attendance`);
    const data = await res.json();
    if (!res.ok) {
      showToast(data.error || 'مش قادر أجيب التفاصيل');
      return;
    }

    attendanceDetailsBox.classList.remove('hidden');
    if (!Array.isArray(data.attendees) || data.attendees.length === 0) {
      attendanceStudentsList.innerHTML = '<li>مفيش حضور متسجل للجلسة دي.</li>';
      return;
    }
    attendanceStudentsList.innerHTML = data.attendees
      .map((attendee) => {
        const time = new Date(attendee.attendedAt).toLocaleTimeString('ar-EG', {
          hour: '2-digit',
          minute: '2-digit'
        });
        return `<li>
          <strong>${attendee.studentName}</strong> (${attendee.username})
          <div>وقت التسجيل: ${time}</div>
        </li>`;
      })
      .join('');
  } catch (err) {
    console.error(err);
    showToast('حصلت مشكلة في تحميل الحضور');
  }
}

async function sendAttendance(sessionCode) {
  try {
    const res = await authFetch('/api/student/attendance', {
      method: 'POST',
      body: JSON.stringify({ sessionCode })
    });
    const data = await res.json();
    if (!res.ok) {
      showToast(data.error || 'الكود مش شغال');
      return;
    }
    showToast(data.message || 'اتسجل حضورك');
    manualSessionInput.value = '';
    await loadStudentHistory();
  } catch (err) {
    console.error(err);
    showToast('مقدرناش نسجل الحضور، حاول تاني');
  }
}

function showError(message) {
  loginError.textContent = message;
  loginError.classList.remove('hidden');
}

function showToast(message) {
  toast.textContent = message;
  toast.classList.remove('hidden');
  setTimeout(() => {
    toast.classList.add('hidden');
  }, 3000);
}

function authFetch(url, options = {}) {
  const opts = { ...options };
  opts.headers = opts.headers || {};
  if (state.token) {
    opts.headers.Authorization = `Bearer ${state.token}`;
  }
  if (opts.body && !opts.headers['Content-Type']) {
    opts.headers['Content-Type'] = 'application/json';
  }
  return fetch(url, opts);
}

async function startScanner() {
  if (qrScanner) {
    showToast('الكاميرا شغالة بالفعل');
    return;
  }
  try {
    qrScanner = new Html5Qrcode('qr-reader', {
      formatsToSupport: [
        Html5QrcodeSupportedFormats.CODE_128,
        Html5QrcodeSupportedFormats.CODE_39,
        Html5QrcodeSupportedFormats.QR_CODE
      ]
    });
    await qrScanner.start(
      { facingMode: 'environment' },
      { fps: 10, qrbox: 250 },
      async (decodedText) => {
        stopScanner();
        await sendAttendance(decodedText);
      },
      (errorMessage) => {
        console.debug('scanner error', errorMessage);
      }
    );
    startScanBtn.classList.add('hidden');
    stopScanBtn.classList.remove('hidden');
  } catch (err) {
    console.error(err);
    showToast('مش قادر أشغل الكاميرا، جرّب تدخل الكود يدوي');
    stopScanner(true);
  }
}

function stopScanner(skipToast = false) {
  if (!qrScanner) {
    return;
  }
  qrScanner
    .stop()
    .then(() => {
      qrScanner.clear();
      qrScanner = null;
      startScanBtn.classList.remove('hidden');
      stopScanBtn.classList.add('hidden');
      if (!skipToast) {
        showToast('اتقفلت الكاميرا');
      }
    })
    .catch((err) => {
      console.error('Error stopping scanner', err);
    });
}